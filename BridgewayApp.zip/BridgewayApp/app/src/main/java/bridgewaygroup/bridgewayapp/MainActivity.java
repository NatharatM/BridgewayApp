package bridgewaygroup.bridgewayapp;

        import android.support.v7.app.AppCompatActivity;
        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.view.View.OnClickListener;
        import android.widget.Button;

public class MainActivity extends AppCompatActivity {


    Button btn1;
    Button btn2;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1=(Button)findViewById(R.id.B1);
        btn1.setOnClickListener(btn1Listener);

        btn2=(Button)findViewById(R.id.B2);
        btn2.setOnClickListener(btn2Listener);
    }


    private View.OnClickListener btn1Listener=new View.OnClickListener() {
        public void onClick(View v) {
            Intent intent1=new Intent(MainActivity.this,Gallery1.class);
            startActivity(intent1);
        }
    };
    private View.OnClickListener btn2Listener=new View.OnClickListener() {
        public void onClick(View v) {
            Intent intent2=new Intent(MainActivity.this,Gallery2.class);
            startActivity(intent2);
        }
    };
}